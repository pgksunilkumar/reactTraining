import React from 'react';
import { Component } from "react";

class App extends Component{

    render(){
        return(
            <h1>This is React App Component!</h1>
        );
    }
}

export default App;